require 'zlib'
require 'find'

class HierarchySearcher
	attr_reader :baseDir, :date
	
	def initialize(baseDir, &condition)
		@parents = Hash.new
		@allStr = "\n"
		@baseDir = baseDir
		@date = Time.now
		
		currParents = Array.new
		
		fileIterator(baseDir, condition) do |f|
			# remove "./"
			f = f[2..-1]
			next if f.nil?
			pathStr = f.split("/")
			next if pathStr.empty?
			# find existing parent directory
			currParents.pop while pathStr.size <= currParents.size
			# add entry
			@parents[@allStr.size] = currParents.last
			currParents.push @allStr.size
			@allStr << pathStr.last << "\n"
		end
	end
	
	def printDebug
		puts "\"#{@allStr}\""
		@parents.each do |val|
			p val
		end
	end
	
	# Search for given string
	def find(str)
		return if str=="" || (str.class == Regexp && str.source.empty?)
		pos = @allStr.index(str)
		while pos
			# yield start pos of this search result
			yield @allStr.rindex("\n", pos)+1
			# goto start of next search result
			pos = @allStr.index(str, @allStr.index("\n",  pos))
		end
	end
	
	def findHierarchy(query)
		@clientParents = Hash.new
		
		find(query) do |index|
			newnodes = Array.new
			
			# go hierarchy down
			while @clientParents[index].nil? && index
				newnodes.push index
				index = @parents[index]
			end
			
			# create while going hierarchy up
			last = @clientParents[index]
			while pos = newnodes.pop
				last = yield(data(pos), last, newnodes.empty?)
				@clientParents[pos] = last				
			end				
		end
	end
	
	def data(pos)
		@allStr[pos..@allStr.index("\n", pos)-1]
	end
	
	def parent(pos)
		@parents[pos]
	end
	
	def fileIterator(baseDir, condition)
		counter = 0
		oldPwd = Dir.pwd
		Dir.chdir baseDir
		Find.find(".") do |f|
			counter += 1
			Find.prune if (condition and condition.call(f, counter))
			yield f
		end
		Dir.chdir oldPwd
	end
	
	def size
		@parents.size
	end
	
	def save(outFile)
		Zlib::GzipWriter.open(outFile) do |gz|
			gz.write Marshal.dump(self)
		end
	end
	
	def HierarchySearcher.load(inFile)
		hier = nil
		Zlib::GzipReader.open(inFile) do |gz|
			hier = Marshal.load(gz.read)
		end
		hier
	end
end

if __FILE__ == $0
	@hier = Hierarchy.new(".") do  |entry|
		entry.include?("System Volume Information")
	end
	
	puts "indexed #{@hier.size} files."
	@hier.save("out.sr")
	
	while true
		str = STDIN.gets.strip
		@hier.find(str) do |pos|
			puts @hier.data(pos)
		end
	end
end
