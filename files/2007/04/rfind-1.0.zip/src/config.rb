class Config
	def initialize
		@rulesStr = ""
	end
	
	def rules=(rulesStr)
		@rulesStr = rulesStr
	end
	
	def rules
		@rulesStr
	end
	
	def match(filename)
		@rulesStr.each_line do |line|
			line.strip!
			next if line.empty? || line[0] == ?#
			split = line.split("\t")
			match = split.first
			command = split.last
			return process(command, filename) if filename =~ Regexp.new(match, Regexp::IGNORECASE)
		end
		return nil
	end
	
	def process(command, filename)
		str = command.dup
		str.gsub!('<filename>', "\"#{filename}\"")
		str.gsub!('<basename>', "\"#{File.basename(filename)}\"")
		# get directory from filename
		dir = filename
		dir = File.dirname(filename) if not File.directory?(filename)
		str.gsub!('<directory>', dir)
		str.strip!
		str
	end
end