require 'hierarchy'
require 'config'
require 'test/unit'

=begin
uses this hierarchy:

test
	blue
		green.txt
	pink.txt
	black.txt
		
=end

class TestHierarchy < Test::Unit::TestCase
	def setup
		@hier = HierarchySearcher.new("test") do  |entry, size|
			entry.include?(".svn") ||
			entry.include?("System Volume Information") ||
			entry.include?("complex")
		end
		
	end
	
	def testFind
		count = 0
		@hier.find(/black/) do |pos|
			count += 1
			assert_equal "black.txt", @hier.data(pos)
			assert_not_nil @hier.parent(pos)
			assert_equal 1, @hier.parent(pos)
			assert_nil @hier.parent(1)
			assert_equal 1, count
		end
		assert_equal 1, count
	end
	
	def testFindString
		count = 0
		@hier.find("black") do |pos|
			count += 1
			assert_equal "black.txt", @hier.data(pos)
			assert_not_nil @hier.parent(pos)
			assert_equal 1, @hier.parent(pos)
			assert_nil @hier.parent(1)
			assert_equal 1, count
		end
		assert_equal 1, count
	end
	
	def testFindBig
		count = 0
		@hier.find(/t/) do |pos|
			count += 1
			case count
			when 1 then assert_equal "test", @hier.data(pos)
			when 2 then assert_equal "black.txt", @hier.data(pos)
			when 3 then assert_equal "pink.txt", @hier.data(pos)
			when 4 then assert_equal "green.txt", @hier.data(pos)
			end
		end
		assert_equal 4, count
	end
	
	def testInit
		assert_equal 5, @hier.size
		@hier = HierarchySearcher.new("test")
		oldSize = @hier.size
		@hier = HierarchySearcher.new("test")
		assert_equal oldSize, @hier.size
	end
	
	def testSave
		@hier.save("out.sr")
		@hier = nil
		@hier = HierarchySearcher.load("out.sr")
		assert_equal 5, @hier.size
		File.delete "out.sr"
	end
	
	def testFindHierarchy
		@arr = Array.new
		count = 0
		@hier.findHierarchy(/g/) do |name, parent, isResult|
			case count
			when 0 then 
				assert_nil parent
				assert_equal "test", name
				assert_equal false, isResult
			when 1 then
				assert_equal "test", parent.name
				assert_equal "blue", name
				assert_equal false, isResult
			when 2 then
				assert_equal "blue", parent.name
				assert_equal "green.txt", name
				assert_equal true, isResult
			end
			count += 1
			assert count <= 3
			HierTest.new(name, parent)
		end
		assert_equal 3, count
	end
	
	def testFullPath
		@hier = HierarchySearcher.new("./././././test") do  |entry, size|
			entry.include?(".svn") ||
			entry.include?("System Volume Information")
		end
		testFindHierarchy
	end	
	
	def testBaseDir
		assert @hier.baseDir.include?("test")
	end
	
	def testEmptySearch
		@hier.find(Regexp.new("")) do |x|
			assert(false, "unreachable code")
		end
		@hier.findHierarchy(Regexp.new("")) do |x|
			assert(false, "unreachable code")
		end
	end
	
	def testDate
		assert Time.now - @hier.date < 2
	end
end

class HierTest
	attr_reader :name, :parent
	def initialize(name, parent)
		@parent = parent
		@name = name
	end
end



class TestConfig < Test::Unit::TestCase
	def testInit
		conf = Config.new
		assert_nil conf.match("x")
	end
	
	def testGetRules
		conf = Config.new
		assert_equal "", conf.rules
		conf.rules = ".mp3	test"
		assert_equal ".mp3	test", conf.rules
	end
	
	def testCase
		conf = Config.new
		conf.rules = "mp3	bla"
		assert_equal "bla", conf.match("MP3")
	end
	
	def testConfig
		conf = Config.new
		conf.rules = '\.mp3$		xmms <filename>
\.html$	firefox <basename>'

		assert_equal 'xmms "./test.mp3"', conf.match("./test.mp3")
		assert_equal 'firefox "test.html"', conf.match("./test.html")
		assert_nil conf.match("topfen.txt")
	end

	def testEmptyLine
		conf = Config.new
		conf.rules = "a	b\n \nc	d"
		assert_equal "d", conf.match("c")
	end	
	
	def testDirectory
		conf = Config.new
		conf.rules = 't	ls <directory>'
		assert_equal 'ls ./test/test', conf.match('./test/test/pink.txt')
		assert_equal 'ls ./test/test', conf.match('./test/test')
		assert_equal 'ls ./test/test/', conf.match('./test/test/')
	end
	
	def testComment
		conf = Config.new
		conf.rules = '#a	comment'
		assert_nil conf.match('#a')
	end
end


# todo: edit window while indexing => crash